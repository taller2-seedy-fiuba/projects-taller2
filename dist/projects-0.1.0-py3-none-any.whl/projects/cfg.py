from youconfigme import AutoConfig

config = AutoConfig()