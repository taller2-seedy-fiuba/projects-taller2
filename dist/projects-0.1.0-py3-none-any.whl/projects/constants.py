"""Constant values and defaults used in multiple modules."""


USER_URL = "https://seedy-fiuba-g1-users.herokuapp.com/"
