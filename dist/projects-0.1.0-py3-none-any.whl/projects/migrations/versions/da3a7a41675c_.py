"""empty message

Revision ID: da3a7a41675c
Revises: 19a94fb7ddd3, 0e23f982e5bf
Create Date: 2021-05-15 18:46:39.834001

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'da3a7a41675c'
down_revision = ('19a94fb7ddd3', '0e23f982e5bf')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
