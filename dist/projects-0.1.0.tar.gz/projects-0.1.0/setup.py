# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['projects',
 'projects.client',
 'projects.migrations',
 'projects.migrations.versions',
 'projects.namespaces.overseer_ns',
 'projects.namespaces.project_ns',
 'projects.namespaces.sponsor_ns',
 'projects.namespaces.users_ns',
 'projects.namespaces.utils']

package_data = \
{'': ['*']}

install_requires = \
['Flask-Cors>=3.0.10,<4.0.0',
 'Flask-Migrate>=2.7.0,<3.0.0',
 'Flask-Script>=2.0.6,<3.0.0',
 'Flask>=1.1.2,<2.0.0',
 'GeoAlchemy2>=0.9.1,<0.10.0',
 'SQLAlchemy-Utils>=0.37.2,<0.38.0',
 'SQLAlchemy<1.4.0',
 'flask-restx>=0.2.0,<0.3.0',
 'gunicorn>=20.1.0,<21.0.0',
 'psycopg2-binary>=2.8.6,<3.0.0',
 'youconfigme>=0.6.14,<0.7.0']

setup_kwargs = {
    'name': 'projects',
    'version': '0.1.0',
    'description': 'Microservice used to manage prijects',
    'long_description': None,
    'author': 'JCaceres2',
    'author_email': 'julieta.a.caceres@tsgforce.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
